package com.laboratorioMicro.laboratorioMicro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaboratorioMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaboratorioMicroApplication.class, args);
	}

}
